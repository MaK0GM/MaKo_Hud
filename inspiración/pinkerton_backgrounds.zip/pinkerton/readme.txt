If installing for default hud:
Just place in custom folder as usual



If installing with custom hud:
Merge the 2 folders in the mod with your huds folders and delete any background files from your hud